## Material Icons

Through most of the examples in this dashboard, we have used the default Icons for the Material Design provided by Google. You can easily use them like this:

<md-icon>favorite</md-icon>

```html
<md-icon>favorite</md-icon>
```

> Note: for more details about the icons please see the **Icon** section from [vuematerial.io](https://vuematerial.io/components/icon)
