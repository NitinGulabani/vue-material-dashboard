let URL;
URL = "http://127.0.0.1:8000";
// Main Menu
export const GETMAINMENULIST = URL + "/api/get_all_main_menu";
